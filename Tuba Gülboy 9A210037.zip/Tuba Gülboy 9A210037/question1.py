foodstock = {"Chicken": 50, "Flour": 73, "Salt": 140, "Sugar": 170, "Oil": 88}
foodprices = {"Chicken": 200, "Flour": 50, "Salt": 30, "Sugar": 45, "Oil": 95}

cleaningstock = {"Detergent": 30, "Soap": 63, "Shampoo": 55, "Floor Cleaner": 45, "Cloth": 68}
cleaningprices = {"Detergent": 62, "Soap": 10, "Shampoo": 70, "Floor Cleaner": 33, "Cloth": 25}

fruitvegetablesstock = {"Pineapple": 15, "Peach": 60, "Grape": 40, "Carrot": 65, "Broccoli": 20}
fruitvegetablesprices = {"Pineapple": 65, "Peach": 40, "Grape": 82, "Carrot": 22, "Broccoli": 36}

total_payment = 0

def displayCategory(category):
    if category == 1:  
        print("Available food products:")
        for product, price in foodprices.items():
            print(product, str(price), "TL", "Stock:", str(foodstock[product]))
    elif category == 2: 
        print("Available cleaning products:")
        for product, price in cleaningprices.items():
            print(product, str(price), "TL", "Stock:", str(cleaningstock[product]))
    elif category == 3: 
        print("Available fruit/vegetable products:")
        for product, price in fruitvegetablesprices.items():
            print(product, str(price), "TL", "Stock:", str(fruitvegetablesstock[product]))

def purchaseProduct(category, product_name, quantity):
    global total_payment
    price = 0
    if category == 1:  
        if foodstock[product_name] >= quantity:
            foodstock[product_name] -= quantity
            price = foodprices[product_name] * quantity
            total_payment += price
            print("Amount to be paid:", str(price), "TL")
            print("Remaining quantity of", product_name + ":", str(foodstock[product_name]))
        else:
            print("Insufficient stock for", product_name)
    elif category == 2:  
        if cleaningstock[product_name] >= quantity:
            cleaningstock[product_name] -= quantity
            price = cleaningprices[product_name] * quantity
            total_payment += price
            print("Amount to be paid:", str(price), "TL")
            print("Remaining quantity of", product_name + ":", str(cleaningstock[product_name]))
        else:
            print("Insufficient stock for", product_name)
    elif category == 3:  
        if fruitvegetablesstock[product_name] >= quantity:
            fruitvegetablesstock[product_name] -= quantity
            price = fruitvegetablesprices[product_name] * quantity
            total_payment += price
            print("Amount to be paid:", str(price), "TL")
            print("Remaining quantity of", product_name + ":", str(fruitvegetablesstock[product_name]))
        else:
            print("Insufficient stock for", product_name)

def displayPayment():
    print("Total payment:", str(total_payment), "TL")

def marketProgram():
    while True:
        print("\n1 - Food\n2 - Cleaning\n3 - Fruit/Vegetable\n4 - Payment\n5 - Exit")
        choice = int(input("Enter your choice: "))
        
        if choice in [1, 2, 3]:
            displayCategory(choice)  
            product_name = input("Enter product name: ")
            if choice == 1 and product_name not in foodprices:
                print("Unsufficient product name. Try again.")
                continue
            elif choice == 2 and product_name not in cleaningprices:
                print("Unsufficient product name. Try again.")
                continue
            elif choice == 3 and product_name not in fruitvegetablesprices:
                print("Unsufficient product name. Try again.")
                continue

            quantity = int(input("Enter quantity: "))
            purchaseProduct(choice, product_name, quantity)  
        elif choice == 4:
            displayPayment()  
        elif choice == 5:
            print("Thank you! We are waiting for you again.")
            break
        else:
            print("Unsufficient choice. Please try again.")

marketProgram()
