import numpy as np
import pandas as pd
import seaborn as sns                      
from matplotlib import pyplot as plt   

#1)Read the dataset.
df=pd.read_csv("student_lifestyle_dataset.csv")
print(df)

#2)List the first 15 data.
print(df.head(15))

#3)Find how many data there are. Show the number of rows and columns.
print(df.shape)

#4)Display column names
print(df.columns)

#5)Display how many 0s and 1s there are in the prediction column (target column) or in any categorical column.
value_counts=df['Sleep_Hours_Per_Day'].value_counts()
print(value_counts)

#6)Draw a histogram. You can do this in any category.
print(sns.countplot(x="Stress_Level",data=df))
print(plt.show())

#7)Display the data types of all parameters.
print(df.dtypes)

#8)Display statistical information about the data set.
print(df.describe().T)

#9)Display missing data in the data set.
print(df.isnull().sum())

#10)Assuming that there is missing data in the data set, show the solution to the problem.
print(df.fillna(value=0, inplace=True))

#11)Find the average of any column consisting of numerical data in the data set.
print(df["Sleep_Hours_Per_Day"].mean())

#12)Find the highest value in any column consisting of numerical data in the data set.
print(df["Social_Hours_Per_Day"].max())

#13)Select and display any three columns.
print(df[["Extracurricular_Hours_Per_Day","Physical_Activity_Hours_Per_Day","GPA"]].head())

#14)Delete any column.
df.drop("Student_ID",axis=1, inplace=True)
print(df)

#15)15.	Convert the categorical values in the columns as text to numerical values. 
#(e.g. change the values of Small, Medium, Large to 1,2,3). If there is no such column, just write the codes assuming that there is.
print(df["Stress_Level"].replace(["Low","Moderate","High"],[1,2,3],inplace=True))
print(df["Stress_Level"].head())